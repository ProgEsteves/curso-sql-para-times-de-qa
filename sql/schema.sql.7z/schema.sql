--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.7
-- Dumped by pg_dump version 9.5.7

-- Started on 2017-06-26 19:21:59 BRT

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 2269 (class 1262 OID 37557)
-- Name: imdb; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE imdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE imdb OWNER TO postgres;

\connect imdb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 1 (class 3079 OID 12397)
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- TOC entry 2272 (class 0 OID 0)
-- Dependencies: 1
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 185 (class 1259 OID 37558)
-- Name: acted_in; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE acted_in (
    idacted_in integer NOT NULL,
    idmovies integer NOT NULL,
    idseries integer,
    idactors integer NOT NULL,
    "character" character varying(2047),
    billing_position integer
);


ALTER TABLE acted_in OWNER TO postgres;

--
-- TOC entry 186 (class 1259 OID 37564)
-- Name: acted_in_idacted_in_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE acted_in_idacted_in_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE acted_in_idacted_in_seq OWNER TO postgres;

--
-- TOC entry 2273 (class 0 OID 0)
-- Dependencies: 186
-- Name: acted_in_idacted_in_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE acted_in_idacted_in_seq OWNED BY acted_in.idacted_in;


--
-- TOC entry 187 (class 1259 OID 37566)
-- Name: actors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE actors (
    idactors integer NOT NULL,
    lname character varying(2047),
    fname character varying(2047),
    mname character varying(2047),
    gender integer,
    number integer
);


ALTER TABLE actors OWNER TO postgres;

--
-- TOC entry 188 (class 1259 OID 37572)
-- Name: aka_names; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE aka_names (
    idaka_names integer NOT NULL,
    idactors integer NOT NULL,
    name character varying(2047)
);


ALTER TABLE aka_names OWNER TO postgres;

--
-- TOC entry 189 (class 1259 OID 37578)
-- Name: aka_names_idaka_names_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE aka_names_idaka_names_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE aka_names_idaka_names_seq OWNER TO postgres;

--
-- TOC entry 2274 (class 0 OID 0)
-- Dependencies: 189
-- Name: aka_names_idaka_names_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE aka_names_idaka_names_seq OWNED BY aka_names.idaka_names;


--
-- TOC entry 191 (class 1259 OID 37586)
-- Name: aka_titles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE aka_titles (
    idaka_titles integer NOT NULL,
    idmovies integer NOT NULL,
    title character varying(2047),
    location character varying(63),
    year integer
);


ALTER TABLE aka_titles OWNER TO postgres;

--
-- TOC entry 192 (class 1259 OID 37592)
-- Name: aka_titles_idaka_titles_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE aka_titles_idaka_titles_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE aka_titles_idaka_titles_seq OWNER TO postgres;

--
-- TOC entry 2275 (class 0 OID 0)
-- Dependencies: 192
-- Name: aka_titles_idaka_titles_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE aka_titles_idaka_titles_seq OWNED BY aka_titles.idaka_titles;


--
-- TOC entry 203 (class 1259 OID 47761)
-- Name: countries_idcountries_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE countries_idcountries_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE countries_idcountries_seq OWNER TO postgres;

--
-- TOC entry 200 (class 1259 OID 46935)
-- Name: countries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE countries (
    idcountries smallint DEFAULT nextval('countries_idcountries_seq'::regclass) NOT NULL,
    country character varying(100) NOT NULL
);


ALTER TABLE countries OWNER TO postgres;

--
-- TOC entry 190 (class 1259 OID 37580)
-- Name: genres; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE genres (
    idgenres integer NOT NULL,
    genre character varying(511)
);


ALTER TABLE genres OWNER TO postgres;

--
-- TOC entry 204 (class 1259 OID 47769)
-- Name: genres_idgenres_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE genres_idgenres_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE genres_idgenres_seq OWNER TO postgres;

--
-- TOC entry 193 (class 1259 OID 37594)
-- Name: keywords; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE keywords (
    idkeywords integer NOT NULL,
    keyword character varying(255)
);


ALTER TABLE keywords OWNER TO postgres;

--
-- TOC entry 202 (class 1259 OID 47759)
-- Name: languages_idlanguages_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE languages_idlanguages_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE languages_idlanguages_seq OWNER TO postgres;

--
-- TOC entry 201 (class 1259 OID 47754)
-- Name: languages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE languages (
    idlanguages smallint DEFAULT nextval('languages_idlanguages_seq'::regclass) NOT NULL,
    language character varying(100)
);


ALTER TABLE languages OWNER TO postgres;

--
-- TOC entry 206 (class 1259 OID 47789)
-- Name: locations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE locations (
    idcountries smallint NOT NULL,
    idmovies integer NOT NULL
);


ALTER TABLE locations OWNER TO postgres;

--
-- TOC entry 194 (class 1259 OID 37597)
-- Name: movies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE movies (
    idmovies integer NOT NULL,
    title character varying(2047),
    year integer,
    number integer,
    type integer,
    location character varying(512),
    language character varying(512),
    plot text,
    release_date character varying(15),
    poster character varying(2047),
    imdbid character varying(15),
    genre character varying(300),
    director character varying(2047),
    writer character varying(2047),
    actors character varying(2047),
    rating real,
    runtime character varying(30),
    award character varying(1023),
    version smallint,
    votes bigint,
    production character varying(511)
);


ALTER TABLE movies OWNER TO postgres;

--
-- TOC entry 195 (class 1259 OID 37603)
-- Name: movies_genres; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE movies_genres (
    idmovies_genres integer NOT NULL,
    idmovies integer NOT NULL,
    idgenres integer NOT NULL,
    idseries integer
);


ALTER TABLE movies_genres OWNER TO postgres;

--
-- TOC entry 196 (class 1259 OID 37606)
-- Name: movies_genres_idmovies_genres_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE movies_genres_idmovies_genres_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE movies_genres_idmovies_genres_seq OWNER TO postgres;

--
-- TOC entry 2276 (class 0 OID 0)
-- Dependencies: 196
-- Name: movies_genres_idmovies_genres_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE movies_genres_idmovies_genres_seq OWNED BY movies_genres.idmovies_genres;


--
-- TOC entry 197 (class 1259 OID 37608)
-- Name: movies_keywords; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE movies_keywords (
    idmovies_keywords integer NOT NULL,
    idmovies integer NOT NULL,
    idkeywords integer NOT NULL,
    idseries integer
);


ALTER TABLE movies_keywords OWNER TO postgres;

--
-- TOC entry 198 (class 1259 OID 37611)
-- Name: movies_keywords_idmovies_keywords_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE movies_keywords_idmovies_keywords_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE movies_keywords_idmovies_keywords_seq OWNER TO postgres;

--
-- TOC entry 2277 (class 0 OID 0)
-- Dependencies: 198
-- Name: movies_keywords_idmovies_keywords_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE movies_keywords_idmovies_keywords_seq OWNED BY movies_keywords.idmovies_keywords;


--
-- TOC entry 205 (class 1259 OID 47784)
-- Name: movies_languages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE movies_languages (
    idmovies integer NOT NULL,
    idlanguages smallint NOT NULL
);


ALTER TABLE movies_languages OWNER TO postgres;

--
-- TOC entry 199 (class 1259 OID 37613)
-- Name: series; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE series (
    idseries integer NOT NULL,
    idmovies integer NOT NULL,
    name character varying(2047),
    season integer,
    number integer,
    release_date character varying(15),
    imdbid character varying(15)
);


ALTER TABLE series OWNER TO postgres;

--
-- TOC entry 2098 (class 2604 OID 37619)
-- Name: idacted_in; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY acted_in ALTER COLUMN idacted_in SET DEFAULT nextval('acted_in_idacted_in_seq'::regclass);


--
-- TOC entry 2099 (class 2604 OID 37620)
-- Name: idaka_names; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aka_names ALTER COLUMN idaka_names SET DEFAULT nextval('aka_names_idaka_names_seq'::regclass);


--
-- TOC entry 2100 (class 2604 OID 37621)
-- Name: idaka_titles; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aka_titles ALTER COLUMN idaka_titles SET DEFAULT nextval('aka_titles_idaka_titles_seq'::regclass);


--
-- TOC entry 2101 (class 2604 OID 37622)
-- Name: idmovies_genres; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY movies_genres ALTER COLUMN idmovies_genres SET DEFAULT nextval('movies_genres_idmovies_genres_seq'::regclass);


--
-- TOC entry 2102 (class 2604 OID 37623)
-- Name: idmovies_keywords; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY movies_keywords ALTER COLUMN idmovies_keywords SET DEFAULT nextval('movies_keywords_idmovies_keywords_seq'::regclass);


--
-- TOC entry 2106 (class 2606 OID 37625)
-- Name: acted_in_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY acted_in
    ADD CONSTRAINT acted_in_pkey PRIMARY KEY (idacted_in);


--
-- TOC entry 2111 (class 2606 OID 37627)
-- Name: actors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY actors
    ADD CONSTRAINT actors_pkey PRIMARY KEY (idactors);


--
-- TOC entry 2114 (class 2606 OID 37629)
-- Name: aka_names_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aka_names
    ADD CONSTRAINT aka_names_pkey PRIMARY KEY (idaka_names);


--
-- TOC entry 2120 (class 2606 OID 37633)
-- Name: aka_titles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aka_titles
    ADD CONSTRAINT aka_titles_pkey PRIMARY KEY (idaka_titles);


--
-- TOC entry 2141 (class 2606 OID 46965)
-- Name: countries_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY countries
    ADD CONSTRAINT countries_pk PRIMARY KEY (idcountries);


--
-- TOC entry 2117 (class 2606 OID 37631)
-- Name: genres_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY genres
    ADD CONSTRAINT genres_pkey PRIMARY KEY (idgenres);


--
-- TOC entry 2123 (class 2606 OID 37635)
-- Name: keywords_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY keywords
    ADD CONSTRAINT keywords_pkey PRIMARY KEY (idkeywords);


--
-- TOC entry 2143 (class 2606 OID 47758)
-- Name: languages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY languages
    ADD CONSTRAINT languages_pkey PRIMARY KEY (idlanguages);


--
-- TOC entry 2147 (class 2606 OID 47793)
-- Name: locations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY locations
    ADD CONSTRAINT locations_pkey PRIMARY KEY (idcountries, idmovies);


--
-- TOC entry 2133 (class 2606 OID 37637)
-- Name: movies_genres_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY movies_genres
    ADD CONSTRAINT movies_genres_pkey PRIMARY KEY (idmovies_genres);


--
-- TOC entry 2136 (class 2606 OID 37639)
-- Name: movies_keywords_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY movies_keywords
    ADD CONSTRAINT movies_keywords_pkey PRIMARY KEY (idmovies_keywords);


--
-- TOC entry 2145 (class 2606 OID 47788)
-- Name: movies_languages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY movies_languages
    ADD CONSTRAINT movies_languages_pkey PRIMARY KEY (idmovies, idlanguages);


--
-- TOC entry 2127 (class 2606 OID 37641)
-- Name: movies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY movies
    ADD CONSTRAINT movies_pkey PRIMARY KEY (idmovies);


--
-- TOC entry 2139 (class 2606 OID 37643)
-- Name: series_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY series
    ADD CONSTRAINT series_pkey PRIMARY KEY (idseries);


--
-- TOC entry 2118 (class 1259 OID 50859)
-- Name: AKA_TITLES_IDMOVIES_INDEX; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AKA_TITLES_IDMOVIES_INDEX" ON aka_titles USING btree (idmovies);


--
-- TOC entry 2130 (class 1259 OID 46953)
-- Name: fki_movies_genres_idgenres_fk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_movies_genres_idgenres_fk ON movies_genres USING btree (idgenres);


--
-- TOC entry 2131 (class 1259 OID 46947)
-- Name: fki_movies_genres_idmovies_fk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_movies_genres_idmovies_fk ON movies_genres USING btree (idmovies);


--
-- TOC entry 2134 (class 1259 OID 46906)
-- Name: fki_movies_keywords_fk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_movies_keywords_fk ON movies_keywords USING btree (idmovies);


--
-- TOC entry 2107 (class 1259 OID 50863)
-- Name: idx_acted_in_idactors; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_acted_in_idactors ON acted_in USING btree (idactors);


--
-- TOC entry 2108 (class 1259 OID 50862)
-- Name: idx_acted_in_idmovies; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_acted_in_idmovies ON acted_in USING btree (idmovies);


--
-- TOC entry 2109 (class 1259 OID 50861)
-- Name: idx_acted_in_idseries; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_acted_in_idseries ON acted_in USING btree (idseries);


--
-- TOC entry 2115 (class 1259 OID 50864)
-- Name: idx_aka_names_idactors; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_aka_names_idactors ON aka_names USING btree (idactors);


--
-- TOC entry 2121 (class 1259 OID 50865)
-- Name: idx_aka_titles_idmovies; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_aka_titles_idmovies ON aka_titles USING btree (idmovies);


--
-- TOC entry 2112 (class 1259 OID 37787)
-- Name: idx_fname_lname; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fname_lname ON actors USING btree (fname, lname);


--
-- TOC entry 2124 (class 1259 OID 37811)
-- Name: idx_movies_year; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_movies_year ON movies USING btree (year);


--
-- TOC entry 2137 (class 1259 OID 50866)
-- Name: idx_series_idmovies; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_series_idmovies ON series USING btree (idmovies);


--
-- TOC entry 2125 (class 1259 OID 50837)
-- Name: movies_location_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX movies_location_idx ON movies USING btree (location);


--
-- TOC entry 2128 (class 1259 OID 37786)
-- Name: movies_title_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX movies_title_idx ON movies USING btree (title);


--
-- TOC entry 2129 (class 1259 OID 50836)
-- Name: movies_version_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX movies_version_idx ON movies USING btree (version);


--
-- TOC entry 2149 (class 2606 OID 47779)
-- Name: movies_genres_idgenres_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY movies_genres
    ADD CONSTRAINT movies_genres_idgenres_fk FOREIGN KEY (idgenres) REFERENCES genres(idgenres);


--
-- TOC entry 2148 (class 2606 OID 46942)
-- Name: movies_genres_idmovies_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY movies_genres
    ADD CONSTRAINT movies_genres_idmovies_fk FOREIGN KEY (idmovies) REFERENCES movies(idmovies);


--
-- TOC entry 2150 (class 2606 OID 46901)
-- Name: movies_keywords_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY movies_keywords
    ADD CONSTRAINT movies_keywords_fk FOREIGN KEY (idmovies) REFERENCES movies(idmovies);


--
-- TOC entry 2271 (class 0 OID 0)
-- Dependencies: 7
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


-- Completed on 2017-06-26 19:22:06 BRT

--
-- PostgreSQL database dump complete
--

