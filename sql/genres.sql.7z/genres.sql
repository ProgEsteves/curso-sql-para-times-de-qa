--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.7
-- Dumped by pg_dump version 9.5.7

-- Started on 2017-06-25 17:16:47 BRT

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

--
-- TOC entry 2200 (class 0 OID 37580)
-- Dependencies: 190
-- Data for Name: genres; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO genres VALUES (1, 'N/A');
INSERT INTO genres VALUES (2, 'Thriller');
INSERT INTO genres VALUES (3, 'Film-Noir');
INSERT INTO genres VALUES (4, 'Western');
INSERT INTO genres VALUES (5, 'Animation');
INSERT INTO genres VALUES (6, 'War');
INSERT INTO genres VALUES (7, 'Adult');
INSERT INTO genres VALUES (8, 'Family');
INSERT INTO genres VALUES (9, 'Adventure');
INSERT INTO genres VALUES (10, 'History');
INSERT INTO genres VALUES (11, 'Musical');
INSERT INTO genres VALUES (12, 'Biography');
INSERT INTO genres VALUES (13, 'Horror');
INSERT INTO genres VALUES (14, 'Reality-TV');
INSERT INTO genres VALUES (15, 'Action');
INSERT INTO genres VALUES (16, 'Comedy');
INSERT INTO genres VALUES (17, 'Talk-Show');
INSERT INTO genres VALUES (18, 'Documentary');
INSERT INTO genres VALUES (19, 'Romance');
INSERT INTO genres VALUES (20, 'Drama');
INSERT INTO genres VALUES (21, 'Fantasy');
INSERT INTO genres VALUES (22, 'Sci-Fi');
INSERT INTO genres VALUES (23, 'Sport');
INSERT INTO genres VALUES (24, 'Mystery');
INSERT INTO genres VALUES (25, 'News');
INSERT INTO genres VALUES (26, 'Crime');
INSERT INTO genres VALUES (27, 'Music');
INSERT INTO genres VALUES (28, 'Short');
INSERT INTO genres VALUES (29, 'Game-Show');


-- Completed on 2017-06-25 17:16:47 BRT

--
-- PostgreSQL database dump complete
--

